<style>
  .sidebar .nav-item .nav-link {
    padding: 12px 22px !important;
  }

  /* Fixed sidenav, full height */
  .sidenav {

    padding-top: 0px;
  }

  /* Style the sidenav links and the dropdown button */
  .sidenav a,
  .dropdown-btn {
    padding: 6px 8px 6px 42px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    color: #67748e;
    display: block;
    border: none;
    background: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    outline: none;
  }

  /* On mouse-over */
  .sidenav a:hover,
  .dropdown-btn:hover {
    color: #67748e;
  }

  .dropdown-item:hover {
    /* color:red; */
    background-color: rgba(255, 255, 255, .2);
  }

  /* Main content */
  /* .main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px;
  /* Increased text to enable scrolling */
  padding: 0px 10px;
  }

  */

  /* Add an active class to the active dropdown button */
  .active {
    /* background-color: green; */
    color: #185be0;
  }

  /* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
  .dropdown-container {
    display: none;
    /* background-color: #262626; */
    padding-left: 8px;
  }

  /* Optional: Style the caret down icon */
  .fa-caret-down {
    float: right;
    padding-right: 8px;
  }

  .navbar-vertical .navbar-nav .nav-item .collapse .nav .nav-item .nav-link:before,
  .navbar-vertical .navbar-nav .nav-item .collapsing .nav .nav-item .nav-link:before {
    width: 0px !important;
  }

  .navbar-vertical .navbar-nav .nav-link[data-bs-toggle="collapse"]:after {
    content: '';
  }

  /* Some media queries for responsiveness */
  @media screen and (max-height: 450px) {
    .sidenav {
      padding-top: 15px;
    }

    .sidenav a {
      font-size: 18px;
    }
  }
</style>
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 "
  id="sidenav-main">
  <div class="sidenav-header">
    <!--<i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href=" https://demos.creative-tim.com/soft-ui-dashboard/pages/dashboard.html " target="_blank">
        <img src="{{ url('dashboard/assets/img/logo-ct-dark.png') }}" class="navbar-brand-img h-100" alt="main_logo">
        <span class="ms-1 font-weight-bold">Tratta System</span>-->
    </a>
  </div>
  <!--<hr class="horizontal dark mt-0">-->
  <div class="collapse navbar-collapse  w-auto mt-7" id="sidenav-collapse-main">
    <ul class="navbar-nav">

      <li class="nav-item">
        <a data-bs-toggle="collapse" href="#dashboardsExamples" class="nav-link active"
          aria-controls="dashboardsExamples" role="button" aria-expanded="true">

          <span class="nav-link-text ms-1" style="width:150px;">
            <img src="{{ url('dashboard/assets/icons/menu_icon/data2.svg') }}">&nbsp;
            Basic Data</span><span><img src="{{ asset('dashboard/assets/img/open_subs.svg') }}"></span>
        </a>
        <div class="collapse" id="dashboardsExamples" style="">
          <ul class="nav ms-4 ps-3" style="list-style-type: none; margin: 0; padding: 0;">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('categories.index') }}">
                <span class="sidenav-normal"> Drug Data </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('illness_categories.index') }}">
                <span class="sidenav-normal"> Illness </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('indications.index') }}">
                <span class="sidenav-normal"> Indication </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#gender">
                <span class="sidenav-normal"> Gender </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#age">
                <span class="sidenav-normal"> Age </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#weight">
                <span class="sidenav-normal"> Weight </span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#prgnancy_stage">
                <span class="sidenav-normal"> Pregnancy Stages</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#prgnancy_safty">
                <span class="sidenav-normal"> Pregnancy Safty Category</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#drug_formula">
                <span class="sidenav-normal"> Drug Formula</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#effect">
                <span class="sidenav-normal"> Effect</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#weight_gender">
                <span class="sidenav-normal"> Weight Gender Ranges</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#crcl_range">
                <span class="sidenav-normal"> Crcl range & Synonym Illness</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#kidney">
                <span class="sidenav-normal"> Kidneys</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#crcl_calculator">
                <span class="sidenav-normal"> Crcl Calculator</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#s.cr_synnonym">
                <span class="sidenav-normal"> S.cr & Synonym Illness</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('basic_data') }}#reckeck_drug">
                <span class="sidenav-normal"> Recheck Drug Hx (Interaction Severity)</span>
              </a>
            </li>
          </ul>
        </div>
      </li>


      <li class="nav-item">
        <a class="nav-link  @if (Route::is('drugs.index') )  active @endif" href="{{ route('drugs.index') }}">

          <span class="nav-link-text ms-1">
            <img src="{{ url('dashboard/assets/icons/menu_icon/CapsulePill.svg') }}">&nbsp;
            Drug Algorithms</span>
        </a>
      </li>
      <li class="sidenav nav-item ">
        <a class="dropdown-btn" style="padding: 6px 4px 6px 30px;">
          <span class="nav-link-text ms-1">
            <img src="{{ url('dashboard/assets/icons/menu_icon/bubble.svg') }}">&nbsp;
            Other Addons</span>
          <span><img src="{{ asset('dashboard/assets/img/open_subs.svg') }}"></span>
        </a>
        <div class="dropdown-container">
          <a class="dropdown-item" style="margin-left: 31px;" href="{{ route('hx_drugs.index') }}">Recheck Drug</a>
          <a class="dropdown-item" style="margin-left: 31px;" href="{{ route('forbidden_cases.index') }}">Forbidden
            case</a>
        </div>
      </li>
      <li class="nav-item mt-3">
        <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Account pages</h6>
      </li>
      <li class="nav-item">
        <a class="nav-link  " href="../pages/profile.html">
          <div
            class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
            <svg width="12px" height="12px" viewBox="0 0 46 42" version="1.1" xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink">
              <title>customer-support</title>
              <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g transform="translate(-1717.000000, -291.000000)" fill="#FFFFFF" fill-rule="nonzero">
                  <g transform="translate(1716.000000, 291.000000)">
                    <g transform="translate(1.000000, 0.000000)">
                      <path class="color-background opacity-6"
                        d="M45,0 L26,0 C25.447,0 25,0.447 25,1 L25,20 C25,20.379 25.214,20.725 25.553,20.895 C25.694,20.965 25.848,21 26,21 C26.212,21 26.424,20.933 26.6,20.8 L34.333,15 L45,15 C45.553,15 46,14.553 46,14 L46,1 C46,0.447 45.553,0 45,0 Z">
                      </path>
                      <path class="color-background"
                        d="M22.883,32.86 C20.761,32.012 17.324,31 13,31 C8.676,31 5.239,32.012 3.116,32.86 C1.224,33.619 0,35.438 0,37.494 L0,41 C0,41.553 0.447,42 1,42 L25,42 C25.553,42 26,41.553 26,41 L26,37.494 C26,35.438 24.776,33.619 22.883,32.86 Z">
                      </path>
                      <path class="color-background"
                        d="M13,28 C17.432,28 21,22.529 21,18 C21,13.589 17.411,10 13,10 C8.589,10 5,13.589 5,18 C5,22.529 8.568,28 13,28 Z">
                      </path>
                    </g>
                  </g>
                </g>
              </g>
            </svg>
          </div>
          <span class="nav-link-text ms-1">Profile</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link  " href="{{ url('dashboard/pages/sign-in.html') }}">
          <div
            class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
            <svg width="12px" height="12px" viewBox="0 0 40 44" version="1.1" xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink">
              <title>document</title>
              <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g transform="translate(-1870.000000, -591.000000)" fill="#FFFFFF" fill-rule="nonzero">
                  <g transform="translate(1716.000000, 291.000000)">
                    <g transform="translate(154.000000, 300.000000)">
                      <path class="color-background opacity-6"
                        d="M40,40 L36.3636364,40 L36.3636364,3.63636364 L5.45454545,3.63636364 L5.45454545,0 L38.1818182,0 C39.1854545,0 40,0.814545455 40,1.81818182 L40,40 Z">
                      </path>
                      <path class="color-background"
                        d="M30.9090909,7.27272727 L1.81818182,7.27272727 C0.814545455,7.27272727 0,8.08727273 0,9.09090909 L0,41.8181818 C0,42.8218182 0.814545455,43.6363636 1.81818182,43.6363636 L30.9090909,43.6363636 C31.9127273,43.6363636 32.7272727,42.8218182 32.7272727,41.8181818 L32.7272727,9.09090909 C32.7272727,8.08727273 31.9127273,7.27272727 30.9090909,7.27272727 Z M18.1818182,34.5454545 L7.27272727,34.5454545 L7.27272727,30.9090909 L18.1818182,30.9090909 L18.1818182,34.5454545 Z M25.4545455,27.2727273 L7.27272727,27.2727273 L7.27272727,23.6363636 L25.4545455,23.6363636 L25.4545455,27.2727273 Z M25.4545455,20 L7.27272727,20 L7.27272727,16.3636364 L25.4545455,16.3636364 L25.4545455,20 Z">
                      </path>
                    </g>
                  </g>
                </g>
              </g>
            </svg>
          </div>
          <span class="nav-link-text ms-1">Sign In</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link  " href="../pages/sign-up.html">
          <div
            class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
            <svg width="12px" height="20px" viewBox="0 0 40 40" version="1.1" xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink">
              <title>spaceship</title>
              <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g transform="translate(-1720.000000, -592.000000)" fill="#FFFFFF" fill-rule="nonzero">
                  <g transform="translate(1716.000000, 291.000000)">
                    <g transform="translate(4.000000, 301.000000)">
                      <path class="color-background"
                        d="M39.3,0.706666667 C38.9660984,0.370464027 38.5048767,0.192278529 38.0316667,0.216666667 C14.6516667,1.43666667 6.015,22.2633333 5.93166667,22.4733333 C5.68236407,23.0926189 5.82664679,23.8009159 6.29833333,24.2733333 L15.7266667,33.7016667 C16.2013871,34.1756798 16.9140329,34.3188658 17.535,34.065 C17.7433333,33.98 38.4583333,25.2466667 39.7816667,1.97666667 C39.8087196,1.50414529 39.6335979,1.04240574 39.3,0.706666667 Z M25.69,19.0233333 C24.7367525,19.9768687 23.3029475,20.2622391 22.0572426,19.7463614 C20.8115377,19.2304837 19.9992882,18.0149658 19.9992882,16.6666667 C19.9992882,15.3183676 20.8115377,14.1028496 22.0572426,13.5869719 C23.3029475,13.0710943 24.7367525,13.3564646 25.69,14.31 C26.9912731,15.6116662 26.9912731,17.7216672 25.69,19.0233333 L25.69,19.0233333 Z">
                      </path>
                      <path class="color-background opacity-6"
                        d="M1.855,31.4066667 C3.05106558,30.2024182 4.79973884,29.7296005 6.43969145,30.1670277 C8.07964407,30.6044549 9.36054508,31.8853559 9.7979723,33.5253085 C10.2353995,35.1652612 9.76258177,36.9139344 8.55833333,38.11 C6.70666667,39.9616667 0,40 0,40 C0,40 0,33.2566667 1.855,31.4066667 Z">
                      </path>
                      <path class="color-background opacity-6"
                        d="M17.2616667,3.90166667 C12.4943643,3.07192755 7.62174065,4.61673894 4.20333333,8.04166667 C3.31200265,8.94126033 2.53706177,9.94913142 1.89666667,11.0416667 C1.5109569,11.6966059 1.61721591,12.5295394 2.155,13.0666667 L5.47,16.3833333 C8.55036617,11.4946947 12.5559074,7.25476565 17.2616667,3.90166667 L17.2616667,3.90166667 Z">
                      </path>
                      <path class="color-background opacity-6"
                        d="M36.0983333,22.7383333 C36.9280725,27.5056357 35.3832611,32.3782594 31.9583333,35.7966667 C31.0587397,36.6879974 30.0508686,37.4629382 28.9583333,38.1033333 C28.3033941,38.4890431 27.4704606,38.3827841 26.9333333,37.845 L23.6166667,34.53 C28.5053053,31.4496338 32.7452344,27.4440926 36.0983333,22.7383333 L36.0983333,22.7383333 Z">
                      </path>
                    </g>
                  </g>
                </g>
              </g>
            </svg>
          </div>
          <span class="nav-link-text ms-1">Sign Up</span>
        </a>
      </li>
    </ul>
  </div>

</aside>
<script>
  /* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>