@extends('dashboard.layouts.master')
@section('content')
@if(Session::has('success'))
<script>
    toastr.success(" {{ Session::get('success') }} ");
</script>
@endif
{{-- /***************** indication ***********/ --}}
@include('dashboard.components.indication')

@endsection