<h1>{{$fixed_dose->doseMessage->recommended_dosage}}</h1>
<h1>{{$fixed_dose->doseMessage->dosage_note}}</h1>
<h1>{{$fixed_dose->doseMessage->titration_note}}</h1>