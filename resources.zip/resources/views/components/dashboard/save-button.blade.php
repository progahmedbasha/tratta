<x-dashboard.button type="submit" style="box-sizing: border-box;width: 150px;height: 36px;left: 1118px;
top: 2651px;background: #3F7090;border: 2px solid #D0D0D5;border-radius: 15px;color: #F3D39D;font-family: 'Ink Free';
">Save</x-dashboard.button>

